package com.meowhome.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int ink = Color.rgb(91, 65, 83);
    private final int pink = Color.rgb(248, 226, 239);
    private final int lilac = Color.rgb(239, 232, 250);
    private final int cream = Color.rgb(255, 249, 250);
    private GridLayout appGrid;
    private EditText search;
    private List<ResolveInfo> allApps = new ArrayList<>();
    private PackageManager pm;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(255,247,251));
        getWindow().setNavigationBarColor(Color.rgb(245,230,240));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        pm = getPackageManager();
        buildScreen();
        loadApps();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(26));
        page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(255,241,248), Color.rgb(244,239,255), Color.rgb(255,249,244)}));
        scroll.addView(page);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("🐾  meow home", 22, ink, true); top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView menu = text("⋯", 30, ink, true); menu.setGravity(Gravity.CENTER); top.addView(menu);
        page.addView(top);

        TextView clock = text(new SimpleDateFormat("h:mm", Locale.getDefault()).format(new Date()), 48, ink, true);
        clock.setGravity(Gravity.CENTER); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(28); page.addView(clock, cp);
        TextView date = text(new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(new Date()), 15, ink, false);
        date.setGravity(Gravity.CENTER); page.addView(date);

        LinearLayout pet = new LinearLayout(this); pet.setOrientation(LinearLayout.VERTICAL); pet.setGravity(Gravity.CENTER);
        pet.setPadding(dp(18), dp(16), dp(18), dp(16)); pet.setBackground(shape(0xDFFFFFFF, dp(28)));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.topMargin = dp(24); page.addView(pet, pp);
        TextView cat = text("ฅ^•ﻌ•^ฅ", 48, 0xFFB56F99, true); cat.setGravity(Gravity.CENTER); pet.addView(cat);
        TextView hello = text("your cozy little corner", 16, ink, true); hello.setGravity(Gravity.CENTER); pet.addView(hello);
        TextView hint = text("Tap your kitty for a little surprise ♡", 12, 0xFF92768A, false); hint.setGravity(Gravity.CENTER); pet.addView(hint);
        cat.setOnClickListener(v -> {
            String[] moods = {"mrrp! ♡", "purr purr…", "meow! ฅ^•ﻌ•^ฅ", "*happy tail wiggle*"};
            hint.setText(moods[(int)(Math.random()*moods.length)]);
        });

        TextView appsTitle = text("your apps  ✿", 18, ink, true);
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(-1, -2); atp.topMargin = dp(26); atp.bottomMargin = dp(10); page.addView(appsTitle, atp);
        search = new EditText(this); search.setSingleLine(true); search.setTextSize(14); search.setHint("Find an app…  🔎");
        search.setPadding(dp(16), 0, dp(16), 0); search.setBackground(shape(0xEFFFFFFF, dp(22)));
        page.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));
        appGrid = new GridLayout(this); appGrid.setColumnCount(4); appGrid.setUseDefaultMargins(false);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(14); page.addView(appGrid, gp);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ renderApps(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
        TextView footer = text("made with whiskers & love  ♡", 12, 0xFF9D8295, false);
        footer.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1,-2); fp.topMargin=dp(22); page.addView(footer,fp);
        setContentView(scroll);
    }

    private void loadApps() {
        Intent intent = new Intent(Intent.ACTION_MAIN); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        allApps = pm.queryIntentActivities(intent, 0);
        Collections.sort(allApps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        renderApps("");
    }
    private void renderApps(String filter) {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        String q = filter.toLowerCase(Locale.getDefault()).trim();
        int count = 0;
        for (ResolveInfo ri : allApps) {
            String label = ri.loadLabel(pm).toString();
            if (!label.toLowerCase(Locale.getDefault()).contains(q)) continue;
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER);
            item.setPadding(dp(3), dp(10), dp(3), dp(10));
            TextView icon = text("", 29, ink, false); icon.setGravity(Gravity.CENTER);
            try { icon.setCompoundDrawablesWithIntrinsicBounds(null, ri.loadIcon(pm), null, null); } catch (Exception ignored) {}
            item.addView(icon, new LinearLayout.LayoutParams(-1, dp(48)));
            TextView name = text(label, 11, ink, false); name.setGravity(Gravity.CENTER); name.setMaxLines(2);
            item.addView(name, new LinearLayout.LayoutParams(-1, dp(34)));
            item.setOnClickListener(v -> {
                try {
                    Intent launch = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
                    if (launch != null) startActivity(launch);
                    else Toast.makeText(this, "This app can't be opened from the launcher", Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this, "Couldn't open app", Toast.LENGTH_SHORT).show(); }
            });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0; lp.height = dp(88); lp.columnSpec = GridLayout.spec(count % 4, 1f);
            appGrid.addView(item, lp); count++;
        }
        if (count == 0) {
            TextView empty = text("No apps found ♡", 14, ink, false); empty.setGravity(Gravity.CENTER);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(); lp.width = -1; lp.height = dp(70); lp.columnSpec = GridLayout.spec(0, 4);
            appGrid.addView(empty, lp);
        }
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
