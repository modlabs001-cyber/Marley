# Meow Home — Android launcher prototype

Meow Home is a lightweight, cat-themed Android HOME launcher prototype. It declares the Android HOME/DEFAULT intent, displays the time/date, a tappable kitty, app search, and a grid of installed launcher apps.

## Build an APK without a computer (GitHub Actions)

This repository includes `.github/workflows/build-apk.yml` to build a debug APK in GitHub's cloud.

1. In your phone browser, sign in to GitHub and create a **new public or private repository**.
2. Upload the contents of this project folder to the repository (keep the `.github/workflows/build-apk.yml` file and its folders).
3. Open the repository's **Actions** tab, select **Build Meow Home APK**, and tap **Run workflow**. If prompted, enable Actions for the repository.
4. When the run finishes successfully, open that run and download the **MeowHome-debug-apk** artifact. Extract the ZIP to get `app-debug.apk`.
5. Tap the APK on your Cricket Android phone to install it. Android may ask you to allow installs from your browser or Files app; only allow this for the APK you built from this project.
6. Open **Settings → Apps → Default apps → Home app** (wording varies by Android version) and select **Meow Home**. You can switch back to your phone's original launcher there.

## Notes

- Cricket is a mobile carrier, not a phone model. This launcher should work on Android 6.0+ devices in principle, but device-specific testing is still needed.
- This is an early launcher prototype, not a full replacement for all features of a manufacturer's launcher.
- Android handles Home-app selection; the app cannot silently make itself the default.
- The debug APK is unsigned with a release key and is intended for personal testing. A production release should use a securely managed signing key.
